using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    public int level = 1;
    public GameObject explorerPrefab;
    public GameObject minotaurPrefab;
    public GameObject tilePrefab;
    public Sprite floorSprite, floorblownSprite, wallSprite, wallblownSprite, walltorchSprite;
    public Sprite potionevileyeSprite, potionhoruseyeSprite, booktreasureSprite;
    public AudioClip potionSpawnSound;
    public GameObject tileContainer;

    public int gridSize = 10;
    public float tileSize = 30f;

    private Tile[,] tiles;
    private Explorer explorer;
    private Minotaur minotaur;

    void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    void Start()
    {
        GenerateLevel();
    }

    public void GenerateLevel()
    {
        ClearLevel();
        tiles = new Tile[gridSize, gridSize];

        for (int y = 0; y < gridSize; y++)
        {
            for (int x = 0; x < gridSize; x++)
            {
                GameObject tileObj = Instantiate(tilePrefab, tileContainer.transform);
                tileObj.transform.localPosition = new Vector3(x * tileSize, y * tileSize, 0);
                Tile tile = tileObj.GetComponent<Tile>();
                tile.Initialize(TileType.Floor);
                tiles[x, y] = tile;
            }
        }

        // TODO: Randomly place walls, potions, and book treasure with constraints
        // TODO: Instantiate explorer and minotaur
    }

    public void ClearLevel()
    {
        foreach (Transform child in tileContainer.transform)
        {
            Destroy(child.gameObject);
        }
    }

    public Tile GetTile(int x, int y)
    {
        if (x >= 0 && x < gridSize && y >= 0 && y < gridSize)
            return tiles[x, y];
        return null;
    }
}

public enum TileType { Floor, FloorBlown, Wall, WallBlown, WallTorch, PotionEvilEye, PotionHorusEye, BookTreasure }