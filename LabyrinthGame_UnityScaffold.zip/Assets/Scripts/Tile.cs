using UnityEngine;

public class Tile : MonoBehaviour
{
    public TileType type;
    public SpriteRenderer spriteRenderer;

    public void Initialize(TileType tileType)
    {
        type = tileType;
        UpdateVisual();
    }

    public void UpdateVisual()
    {
        switch (type)
        {
            case TileType.Floor: spriteRenderer.sprite = GameManager.Instance.floorSprite; break;
            case TileType.FloorBlown: spriteRenderer.sprite = GameManager.Instance.floorblownSprite; break;
            case TileType.Wall: spriteRenderer.sprite = GameManager.Instance.wallSprite; break;
            case TileType.WallBlown: spriteRenderer.sprite = GameManager.Instance.wallblownSprite; break;
            case TileType.WallTorch: spriteRenderer.sprite = GameManager.Instance.walltorchSprite; break;
            case TileType.PotionEvilEye: spriteRenderer.sprite = GameManager.Instance.potionevileyeSprite; break;
            case TileType.PotionHorusEye: spriteRenderer.sprite = GameManager.Instance.potionhoruseyeSprite; break;
            case TileType.BookTreasure: spriteRenderer.sprite = GameManager.Instance.booktreasureSprite; break;
        }
    }
}